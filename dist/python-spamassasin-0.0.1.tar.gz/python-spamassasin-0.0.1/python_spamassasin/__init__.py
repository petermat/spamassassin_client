from spamassasin import SpamAssassin

name = "python-spamassasin"

